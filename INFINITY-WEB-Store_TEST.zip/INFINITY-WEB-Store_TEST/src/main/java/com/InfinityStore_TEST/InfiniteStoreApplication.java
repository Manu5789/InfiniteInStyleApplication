package com.InfinityStore_TEST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfiniteStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfiniteStoreApplication.class, args);
		System.out.println("Ok............");
	}

}
